import {db} from '../db.js'
import qs from 'qs'


export const refri = (req,res)=> res.render("refri.ejs")