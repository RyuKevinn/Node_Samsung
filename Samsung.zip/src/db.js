import mysql from 'mysql'

export const db = mysql.createConnection({          //연결 하기 위한 값
    host:       'localhost',
    user:       'root',
    password:   '',
    database:   'samsung',

})
db.connect()            //mysql 연결