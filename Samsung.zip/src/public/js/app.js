const messageList = document.querySelector("ul")
const messageForm = document.querySelector("form")

const socket = new WebSocket(`ws://${window.location.host}`)

socket.addEventListener("open", ()=>console.log("Connected to Server Start"))

socket.addEventListener("message", (msg)=>{
    console.log(msg.data)
    const li = document.createElement("li")
    li.textContent = msg.data
    messageList.append(li)
})

function handleSubmit(e){
    e.preventDefault()
    const input = messageForm.querySelector("input")
    socket.send(input.value)
    input.value = ""
}

messageForm.addEventListener("submit", handleSubmit)