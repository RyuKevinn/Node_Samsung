// 메인 파트별 호버시 scale
$('#main .depth1 .ani').on('mouseover mouseout',function(){
    $(this).toggleClass('big')
    $(this).css({transition:'all 0.5s'})
})


// scale 없는 파트 호버시 비율 변경
$('#main .depth1 .ac').on('mouseover mouseout',function(){
    $(this).toggleClass('active')
});

// 검색창 클릭 시 fadeIn/Out
$('#main .depth1 .content2 .box4').on('click',function(){
    $('#main .searchbox').toggleClass('on')
    
})

// sns 박스 
$('#main .depth1 .content4 .box3> i').on('click',function(){
    $('#main .depth1 .content4 .box3').toggleClass('on')
    if($(this).hasClass('fa-plus')){
        $(this).addClass('fa-minus').removeClass('fa-plus')
    } else{ $(this).addClass('fa-plus').removeClass('fa-minus')
    }
})

$('#main .depth1 .content4 .box3 i').on('mouseover mouseout',function(){
    $(this).toggleClass('on')
})


// A/S센터 + Q & A  클릭 시   Roll up/Down
$('#main .depth1 .content4 .box4 .sbox1').on('click',function(){
    if($('#main .depth1 .content4 .box5 .sbox2').hasClass('on')){
        $('#main .depth1 .content4 .box5 .sbox2').removeClass('on')
        $('#main .depth1 .content4 .box5 .sbox1').toggleClass('on')
    }else{
    $('#main .depth1 .content4 .box5 .sbox1').toggleClass('on')
    $('#main .depth1 .content4 .box6').toggleClass('on')
    }
})

$('#main .depth1 .content4 .box6').on('click',function(){
    if($('#main .depth1 .content4 .box6').hasClass('on')){
        $('#main .depth1 .content4 .box5 .sbox1').removeClass('on')
        $('#main .depth1 .content4 .box5 .sbox2').removeClass('on')
        // $(this).addClass('on')
        $(this).removeClass('on')
    }
})

//슬라이드

$('#main .slideInner').slick({
    autoplay: true,
    arrows:false
    
})




