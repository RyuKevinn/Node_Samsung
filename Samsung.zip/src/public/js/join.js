$('.appForm').on('submit',function(){

        var userid = $('#userid').val()
        console.log(userid)
    if(!userid){
        alert('아이디를 입력하세요')
        return false
    }
    if(!$('.idcheck').hasClass('on')){
        alert('아이디 중복체크를 해주세요')
        return false
    }

    var pwd = $('#pw').val()
    if(!pwd){
        alert('비밀번호를 입력하세요')
        return false
    }

    let pwdCheck = /^(?=[a-zA-Z])(?=.*[^a-zA-Z0-9])(?=.*[0-9]).*$/
    if ( !pwdCheck.test(pwd) ) {
        alert('비밀번호는 영문, 숫자, 특수문자 중 3가지 이상 조합. 첫글자는 영어만 허용')
        return false
    }

    var pwdok = $('#pwchk').val()
    if(!pwdok){
        alert('비밀번호 확인란을 입력하세요')
        return false
    }else if(pwd!==pwdok){
        alert('비밀번호가 일치하지 않습니다')
        return false
    }

    var username = $('#username').val()
    if(!username){
        alert('이름을 입력하세요')
        return false
    }
    let name = $('#username').val()
    let nameCheck = /^[가-힣]+$/
    if ( !nameCheck.test(name) ) {
        alert('이름은 한글만 입력하세요.')
        return false
    }

    var hpnum = $('#hp').val()
    if(!hpnum){
        alert('전화번호를 입력하세요')
        return false
    }

    var emailid = $('#emailid').val()
    if(!emailid){
        alert('이메일을 입력하세요')
        return false
    }
    var emaildomain = $('#emaildomain').val()
    if(!emaildomain){
        alert('이메일 주소가 입력되지 않았습니다')
        return false    
    }

})


$('#emailList').on('change', function(){
    let opt = $(this).find('option:selected').val()
    if ( opt !== 'title' && opt !== 'self') {
        $('#emaildomain').val(opt).css({
            backgroundColor:'#f2f2f2'
        }).attr({ disabled:false })
    } else if (opt=='self') {
        $('#emaildomain').val('').css({
            backgroundColor:'#fff'
        }).attr({ disabled:false })
    } else {
        $('#emaildomain').val('').css({
            backgroundColor:'#f2f2f2'
        }).attr({ disabled:true })
    }
})










$.datepicker.setDefaults({
    dateFormat: 'yy-mm-dd',
    prevText: '이전 달',
    nextText: '다음 달',
    monthNames: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    monthNamesShort: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    dayNames: ['일', '월', '화', '수', '목', '금', '토'],
    dayNamesShort: ['일', '월', '화', '수', '목', '금', '토'],
    dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'],
    showMonthAfterYear: true,
    yearSuffix: '년'
})

var now = new Date()
var nowYear = now.getFullYear()


$('#birthday').datepicker({
    changeMonth:true,     // 월 선택
    changeYear:true,      // 연도 선택
    yearRange:'1930:'+nowYear   // 연도 범위
}).attr({
    autocomplete:'off'
})

$('.loginForm li input').on('focus',function(){
    $(this).parent().addClass('on')
    $(this).parent().siblings().removeClass('on')
})