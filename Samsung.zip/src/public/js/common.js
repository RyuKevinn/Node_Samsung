
// 퀵메뉴

$('.quickmenu .sq').on('click',function(){
    $(this).parent().toggleClass('on')
    
})

$('.quickmenu .more.down i').on('click',function(){
    $('.quickmenu .depth1').css({transform:'translateY(-78%)'})
})
$('.quickmenu .more.up i').on('click',function(){
    $('.quickmenu .depth1').css({transform:'unset'})
})

$('#nav ul li').on('click',function(){
    $(this).addClass('on').siblings().removeClass('on')
})


$('#nav ul li').on('mouseover',function(){
    $(this).find('span').addClass('on')
})
$('#nav ul li').on('mouseout',function(){
    $(this).find('span').removeClass('on')
})

$('#main .depth1 li .txt a').on('mouseover mouseout',function(){
    $(this).toggleClass('on')
})
