import express from 'express'
import {register,logout,edit,editing,remove,idchk, findid,findingid,findpw,findingpw} from '../controllers/userController'



const userRouter = express.Router()


userRouter.post('/register',register)       //진행
userRouter.get('/logout',logout)            //진행
userRouter.get('/edit',edit)
userRouter.post('/editing',editing)          //진행
userRouter.get('/remove',remove)            //진행
userRouter.get('/idchk',idchk)              //진행
userRouter.route('/findid').get(findid).post(findingid)
userRouter.route('/findpw').get(findpw).post(findingpw)





export default userRouter