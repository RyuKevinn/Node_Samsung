import express from 'express'
import {join , login,loging} from '../controllers/userController'
import {db} from '../db.js'
import qs from 'qs'

const globalRouter = express.Router();

const handleHome = (req,res)=>{
    db.query('select * from freeboard order by idnum desc',[],(error,rows)=>{
        if(error){
            throw error
        }
        res.render("index.ejs",{data:rows})
    })
}

globalRouter.get('/',handleHome)
globalRouter.get('/join',join)
globalRouter.route('/login').get(login).post(loging)


export default globalRouter;