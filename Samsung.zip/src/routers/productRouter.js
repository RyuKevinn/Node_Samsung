import express from 'express'
import {refri} from '../controllers/productController'



const productRouter = express.Router()

productRouter.get('/refrigerator',refri)






export default productRouter