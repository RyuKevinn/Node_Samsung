


create table samsung(
    idnum int not null auto_increment,
    userid varchar(20) not null unique,
    pwd varchar(20) not null,
    irum varchar(20) not null,
    phone int(20) not null,
    email varchar(20) not null,
    birthday varchar(20) not null,
    registday date not null,
    primary key(idnum)
);

create table freeboard(
    idnum int not null auto_increment,
    title varchar(30) not null,
    userid varchar(20) not null,
    content varchar(300) not null,
    wdate varchar(15) not null,
    hit int,
    primary key(idnum),
    foreign key(userid) references samsung(userid)
);